using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Win : MonoBehaviour
{
    string[] trueAns = { "START", "FOOTBALL", "SANDWICH", "HOTDOG", "EARRING", "HORSESHOE", "KEYBOARD", "CUPCAKE", "JUMPROPE", "ICEBOX", "HANDSHAKE", "JELLYFISH", "SUITCASE", "LIPSTICK", "CHECKBOOK", "WEBMAIL", "LADYBUG", "MOUTHWASH", "BEANBAG", "LAYOFF", "MOUSETRAP", "CANDYCANE", "MANHOLE", "JIGSAW" };
    string curAns = "";
    int levelNo = 0;
    

    public GameObject btnPrefeb, WinHolder;

    // Start is called before the first frame update
    void Start()
    {
        levelNo = PlayerPrefs.GetInt("levelNo", 1);
        curAns = trueAns[levelNo - 2];
        for (int i = 0; i <curAns.Length; i++)
        {
            string c = curAns[i] + "";
            

            GameObject g = Instantiate(btnPrefeb, WinHolder.transform);
            
            g.GetComponentInChildren<Text>().text = c;
     
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnWord()
    {
       
        SceneManager.LoadScene("Play");
    }
}
