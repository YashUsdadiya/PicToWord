
using System.Collections;
using System.Collections.Generic;
using Unity.Collections.LowLevel.Unsafe;
using Unity.VisualScripting.Antlr3.Runtime.Tree;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using DG.Tweening;




public class Play : MonoBehaviour
{
    public Sprite[] ImgPuzzle1;
    public Sprite[] ImgPuzzle2;
    public Image Img1, Img2;
    public Text levelNoText,Score,hintText;
    public GameObject WinObj , PlayObj,SettingObj,AboutObj,HintObj;
    // public Button submit;
    int score = 0,cnt=0;
    int levelNo,MaxLevelNo=0;
    string[] trueAns = { "START", "FOOTBALL", "SANDWICH", "HOTDOG", "EARRING", "HORSESHOE", "KEYBOARD", "CUPCAKE", "JUMPROPE", "ICEBOX", "HANDSHAKE", "JELLYFISH", "SUITCASE", "LIPSTICK", "CHECKBOOK", "WEBMAIL", "LADYBUG", "MOUTHWASH", "BEANBAG", "LAYOFF", "MOUSETRAP", "CANDYCANE", "MANHOLE", "JIGSAW" };
    string[] HintText = { "S---T", "F--T---L", "S----I--", "HO-D-G", "E-R-I-G", "H-R-E-H-E", "KEYBOARD", "CUPCAKE", "JUMPROPE", "ICEBOX", "HANDSHAKE", "JELLYFISH", "SUITCASE", "LIPSTICK", "CHECKBOOK", "WEBMAIL", "LADYBUG", "MOUTHWASH", "BEANBAG", "LAYOFF", "MOUSETRAP", "CANDYCANE", "MANHOLE", "JIGSAW" };
    string[] mixedAns = { "BSFSTFGAHFRGHT", "SFGOFOYTUBIALL", "SAFNGDRWWIDCKH", "HODSTFDEOJGKGR", "EAARSRFIGNHGJK", "HOFRSXEESHNOGE", "KAEYSBDOFAGRHD", "CUSPCADFGKHJEK", "JUDDMPMEROTPYE", "ISCEDEBBCOVDXD", "HAANWDSEHARKTE", "JEXLJLYVFITSHY", "SAUTITUCHANSFE", "LUIKPTSTFIXCKZ", "CHVEJCKKBHOOIK", "WVENBMRLMAYILI", "LBADDWYEBDUFGG", "QMOWUTFHWDASGH", "MBENABNBCVADGS", "BLCAFYTOYFUFI", "MSOUDSEFTGRNAP", "HCADNDYECAWNSE", "MFAHNKHFORLYEK", "BJVICXGLSKAJWG" };
    string curAns = "", curMixedAns = "";
    
    public GameObject btnPrefeb, UpperHolder, DownHolder;
    int[] btnpos = new int[10];
    

    // Start is called before the first frame update
    void Start()
    {
        cnt = 0;
        levelNo = PlayerPrefs.GetInt("levelNo", 1);
        MaxLevelNo = PlayerPrefs.GetInt("maxLevelNo", 0);
        levelNoText.text = "Puzzle " + levelNo;
        curAns = trueAns[levelNo-1];
        curMixedAns=mixedAns[levelNo-1];

       // submit.interactable = false;

        Img1.sprite = ImgPuzzle1[levelNo-1];
        Img2.sprite = ImgPuzzle2[levelNo-1];
        //upper btn code
        for(int i = 0; i < curAns.Length; i++)
        {
            GameObject g= Instantiate(btnPrefeb, UpperHolder.transform);
            g.tag = "upper-btn";
            int tempNo = i;
            
            g.GetComponent<Button>().onClick.AddListener(() => upperBtnClick(tempNo));
           
        }
        //down btn code
        for(int i = 0; i < curMixedAns.Length; i++)
        {
            string c = curMixedAns[i] + "";
            int tempNo = i;
            
            GameObject g=Instantiate(btnPrefeb,DownHolder.transform);
            g.tag = "down-btn";
            g.GetComponentInChildren<Text>().text = c;
           
            g.GetComponent<Button>().onClick.AddListener(() => downBtnClick(c, tempNo));
        


        }
        score = PlayerPrefs.GetInt("score", 300);
        Score.text = score + "";
    }

    // Update is called once per frame
    void Update()
    {

    }
        
    //btn repalce down to upper
    void downBtnClick(string str,int no)
    {
           GameObject[] upperBtns = GameObject.FindGameObjectsWithTag("upper-btn");
           GameObject[] downBtns = GameObject.FindGameObjectsWithTag("down-btn");
            

            for(int i = 0;i < upperBtns.Length;i++)
            {
            
            if (upperBtns[i].GetComponentInChildren<Text>().text == "")
            {
                    btnpos[i] = no;
                    upperBtns[i].GetComponentInChildren<Text>().text = str;//add btn text to upper btn
                  
                    downBtns[no].GetComponentInChildren<Text>().text = "";
                    downBtns[no].GetComponent<Button>().interactable = false;//btn click flase
                     
             
                    break;
                }
            }
        string userAns = "";
        for (int i = 0; i < upperBtns.Length; i++)
        {
            userAns += upperBtns[i].GetComponentInChildren<Text>().text;
        }
        if (curAns.Length == userAns.Length)
        {
            if (curAns == userAns)
            {
                PlayerPrefs.SetInt("levelNo", levelNo + 1);
                if (MaxLevelNo <= levelNo)
                {
                    PlayerPrefs.SetInt("maxLevelNo", levelNo);
                }
                PlayerPrefs.SetInt("score", score + 150);
                PlayObj.SetActive(false);
                WinObj.SetActive(true);
            }
            
        }

    }

    void upperBtnClick(int no)
    {
        GameObject[] upperBtns = GameObject.FindGameObjectsWithTag("upper-btn");
        GameObject[] downBtns = GameObject.FindGameObjectsWithTag("down-btn");
        int dowNo = btnpos[no];
        downBtns[dowNo].GetComponent<Button>().interactable = true;
        downBtns[dowNo].GetComponentInChildren<Text>().text = upperBtns[no].GetComponentInChildren<Text>().text;
        upperBtns[no].GetComponentInChildren<Text>().text="";
        upperBtns[no].transform.DOScale(Vector3.one, 0.1f).SetEase(Ease.InBack);


    }

    public void clear()
    {
        SceneManager.LoadScene("Play");
    }

    public void setting()
    {
        SettingObj.SetActive(true);
        
    }

    public void CloseSetting()
    {
        SettingObj.SetActive(false);
    }

    public void HomeBtn()
    {
        SceneManager.LoadScene("Home");
    }

    public void LevelBtn()
    {
        SceneManager.LoadScene("Levels");
    }
    public void AboutBtn()
    {
        SettingObj.SetActive(false);
        AboutObj.SetActive(true);
    }
    public void Close_AboutUs()
    {
        AboutObj.SetActive(false );
    }

    public void Hint()
    {
        HintObj.SetActive(true);
        if (HintText.Length > levelNo)
        {
            if (score >= 300 || cnt==1)
            {
                hintText.text = HintText[levelNo - 1];
                if (cnt == 0)
                {
                    score = score - 200;
                }
                cnt++;
                Score.text =""+score;
                PlayerPrefs.SetInt("score", score);
            }
            else
            {
                hintText.text = "Your Score is less than 300";
            }
        }
        else
        {
            hintText.text = "No Hint Available";
            print(HintText.Length);
        }
    }
    public void close_hint()
    {
        HintObj.SetActive(false) ;
    }

    
}
