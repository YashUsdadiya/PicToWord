using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Levels : MonoBehaviour
{
    public GameObject Page1,Page2,Next,Back;
    public Button[] AllBtn;
    int levelNo = 0;
    public Sprite ticksign;
    int MaxLevelNo = 0;


    // Start is called before the first frame update
    void Start()
    {
        levelNo = PlayerPrefs.GetInt("levelNo", 1);
        MaxLevelNo = PlayerPrefs.GetInt("maxLevelNo", 1);
        for (int i = 0; i <= MaxLevelNo; i++)
        {

            AllBtn[i].interactable = true;

            AllBtn[i].GetComponentInChildren<Text>().text = (i + 1).ToString();
            if (i < MaxLevelNo)
            {
                if (PlayerPrefs.HasKey("skip_" + (i + 1)))
                {
                    AllBtn[i].GetComponent<Image>().sprite = null;
                }
                else
                {
                    AllBtn[i].GetComponent<Image>().sprite = ticksign;
                }
            }
            else
            {
                AllBtn[i].GetComponent<Image>().sprite = null;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void levelBtnClick(int no)
    {

        PlayerPrefs.SetInt("levelNo", no);
        SceneManager.LoadScene("Play");
    }
    public void next()
    {
        Page1.SetActive(false);
        Page2.SetActive(true);
    }

    public void back()
    {
        Page1.SetActive(true);
        Page2.SetActive(false);
    }

}
